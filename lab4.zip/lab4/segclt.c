#include "libseg.a"
#include "segdef.h"

int main() {
    return 0;
}
